#include "pgrp_dat.h"

int  lat_C1_sgrp[NC1_sgrp]={
   TRICLINIC   /*  1  */
};
int  lat_Ci_sgrp[NCi_sgrp]={
   TRICLINIC   /*  1  */
};

char  *comnt_C1_sgrp[NC1_sgrp]={
  "1 (P 1)"       /*  1  */
};
char  *comnt_Ci_sgrp[NCi_sgrp]={
  "2 (P -1)"       /*  1  */
};

double rC1_sgrp[NC1_sgrp][1*3]={
  { /*  1  */
     0.0000,  0.0000,  0.0000  /*    1  */
  }
};
double rCi_sgrp[NCi_sgrp][2*3]={
  { /*  1  */
     0.0000,  0.0000,  0.0000, /*    1  */
     0.0000,  0.0000,  0.0000  /*    2  */
  }
};



